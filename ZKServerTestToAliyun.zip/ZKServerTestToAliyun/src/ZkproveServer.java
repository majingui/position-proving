import com.alibaba.fastjson.JSON;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ZkproveServer { //生成零知识证明的服务器
    static class CreateZKThread implements Runnable{ //每个线程对应一个用户的请求
        private Socket WitnessSocket; //该用户对应的Socket类
        CreateZKThread(Socket WitnessSocket){
            this.WitnessSocket=WitnessSocket;
        }
        @Override
        public void run() {
            try{
                PrintStream SendToWitness = new PrintStream(WitnessSocket.getOutputStream());//Socket.getOutputStream类：得到的是一个输出流，服务端的Socket对象上的getOutputStream方法得到的输出流其实就是发送给客户端的数据。
                Scanner RecieveFromWitness = new Scanner(WitnessSocket.getInputStream());//Witness.getInputStream类：到一个输入流，服务端的Socket对象上的getInp
                while(true){ //等待客户端发来的注册消息
                    if(RecieveFromWitness.hasNext()){ //如果收到发来的ZkReq
                        String ZkReqJSON =  RecieveFromWitness.next();
                        System.out.println(ZkReqJSON);
                        ZeroKReq zeroKReq = JSON.parseObject(ZkReqJSON, ZeroKReq.class); //将客户端传来的JSON转化为类
                        int Px = zeroKReq.getPx();
                        int Py = zeroKReq.getPy();
                        int Pz = zeroKReq.getPz();

                        int Wx = zeroKReq.getWx();
                        int Wy = zeroKReq.getWy();
                        int Wz = zeroKReq.getWz();

                        int R = zeroKReq.getR();
                        String response = CreateZKprover.ZKProve(Px,Py,Pz,Wx,Wy,Wz,R);
                        System.out.println("ok"+R);
                        SendToWitness.println(response); //将零知识证明字符发回给证明者
                        break;
                    }
                }
                if(SendToWitness!=null)
                    SendToWitness.close();
                if(RecieveFromWitness!=null)
                    RecieveFromWitness.close();
                if(WitnessSocket !=null)
                    WitnessSocket.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
    public static void main(String[] args) throws IOException {
        System.out.println("Sever Start");
        ExecutorService executorService = Executors.newFixedThreadPool(3); //最多同时执行3线程
        ServerSocket serverSocket = new ServerSocket(8080);
        while(true){
            Socket Witness = serverSocket.accept(); //服务器开启请求监听，该语句将阻塞，直到有用户请求连接
            System.out.println("New witness:"+Witness.getInetAddress()+":"+Witness.getPort()+"\n");
            executorService.execute(new CreateZKThread(Witness));
        }
    }
}
