public class ZeroKReq {
    private Integer px;
    private Integer py;
    private Integer pz;
    private Integer wx;
    private Integer wy;
    private Integer wz;
    private Integer R;

    public Integer getPx() {return px;}
    public void setPx(Integer px) {this.px = px;}
    public Integer getPy() {return py;}
    public void setPy(Integer py) {this.py = py;}
    public Integer getPz() {return pz;}
    public void setPz(Integer pz) {this.pz = pz;}

    public Integer getWx() {return wx;}
    public void setWx(Integer wx) {this.wx = wx;}
    public Integer getWy() {return wy;}
    public void setWy(Integer wy) {this.wy = wy;}
    public Integer getWz() {return wz;}
    public void setWz(Integer wz) {this.wz = wz;}

    public Integer getR() {return R;}
    public void setR(Integer r) {R = r;}
}
