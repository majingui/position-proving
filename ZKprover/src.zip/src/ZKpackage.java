import java.math.BigInteger;
public class ZKpackage {
    private BigInteger N;
    private BigInteger A;
    private BigInteger S;
    private BigInteger [] b;
    private BigInteger [] x;
    private BigInteger g;
    private Integer R;
    private BigInteger [] beta;
    private BigInteger lambda;
    private BigInteger p;
    private BigInteger r1;
    private BigInteger gamma;
    private BigInteger h;
    private BigInteger [] l;
    private BigInteger m;


    public BigInteger getN() {
        return N;
    }
    public void setN(BigInteger N) {this.N = N;}

    public BigInteger getA() {
        return A;
    }
    public void setA(BigInteger A) {this.A = A;}

    public BigInteger getS() {
        return S;
    }
    public void setS(BigInteger S) {this.S = S;}

    public BigInteger[] getB() {
        return b;
    }
    public void setB(BigInteger []b) {this.b = b;}

    public BigInteger[] getX() {
        return x;
    }
    public void setX(BigInteger []x) {this.x = x;}


    public BigInteger getG() {
        return g;
    }
    public void setG(BigInteger g) {this.g = g;}

    public Integer getR() {
        return R;
    }
    public void setR(Integer R) {this.R = R;}

    public BigInteger[] getBeta() {
        return beta;
    }
    public void setBeta(BigInteger []beta) {this.beta = beta;}

    public BigInteger getLambda() {
        return lambda;
    }
    public void setLambda(BigInteger lambda) {this.lambda = lambda;}

    public BigInteger getP() {
        return p;
    }
    public void setP(BigInteger p) {this.p = p;}

    public BigInteger getR1() {
        return r1;
    }
    public void setR1(BigInteger r1) {this.r1 = r1;}

    public BigInteger getGamma() {return gamma;}
    public void setGamma(BigInteger gamma) {this.gamma = gamma;}

    public BigInteger getH() {return h;}
    public void setH(BigInteger h) {this.h = h;}

    public BigInteger[] getL() {return l;}
    public void setL(BigInteger []l) {this.l = l;}

    public BigInteger getM() {return m;}
    public void setM(BigInteger m) {this.m = m;}
}
